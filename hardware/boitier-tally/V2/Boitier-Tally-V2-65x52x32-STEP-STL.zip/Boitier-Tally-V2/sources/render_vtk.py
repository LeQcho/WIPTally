"""Rendus des STL réels de V2, sans modification de la géométrie."""
from pathlib import Path
import vtk
from PIL import Image, ImageDraw, ImageFont

root=Path(__file__).resolve().parent.parent
images=root/'rendus'
bg=(.965,.957,.931)
black=(.25,.28,.30); white=(.94,.93,.87); carrier=(.36,.40,.42)

def actor(name,color,offset=(0,0,0)):
    reader=vtk.vtkSTLReader();reader.SetFileName(str(images/(name+'.stl')));reader.Update()
    normals=vtk.vtkPolyDataNormals();normals.SetInputData(reader.GetOutput());normals.SetFeatureAngle(30);normals.Update()
    mapper=vtk.vtkPolyDataMapper();mapper.SetInputData(normals.GetOutput())
    a=vtk.vtkActor();a.SetMapper(mapper);a.SetPosition(*offset)
    a.GetProperty().SetColor(*color);a.GetProperty().SetAmbient(.35);a.GetProperty().SetDiffuse(.65)
    return a

def render(name,items,eye=(-100,120,110),size=(1100,800)):
    ren=vtk.vtkRenderer();ren.SetBackground(*bg)
    for n,c,t in items:ren.AddActor(actor(n,c,t))
    cam=ren.GetActiveCamera();cam.ParallelProjectionOn();cam.SetPosition(*eye);cam.SetViewUp(0,0,1)
    win=vtk.vtkRenderWindow();win.SetOffScreenRendering(1);win.SetSize(*size);win.AddRenderer(ren)
    ren.ResetCamera();cam.Zoom(1.12);win.Render()
    capture=vtk.vtkWindowToImageFilter();capture.SetInput(win);capture.SetInputBufferTypeToRGB();capture.ReadFrontBufferOff();capture.Update()
    writer=vtk.vtkPNGWriter();writer.SetFileName(str(images/(name+'.png')));writer.SetInputConnection(capture.GetOutputPort());writer.Write();win.Finalize()
    print(name,flush=True)

zero=(0,0,0)
render('assemble',[(n,white if n.startswith('diffuseur') else black,zero) for n in ['socle','couvercle','diffuseur_avant','diffuseur_arriere']])
render('interieur',[(n,c,zero) for n,c in [('socle',black),('support_ESP',carrier),('support_LED_avant',carrier),('support_LED_arriere',carrier),('carte_nominale',(.39,.27,.56)),('USB_nominal',(.68,.69,.70))]],eye=(-70,75,155))
render('eclate',[
    ('socle',black,zero),('couvercle',black,(0,0,43)),('support_ESP',carrier,(0,0,24)),
    ('support_LED_avant',carrier,(0,3,18)),('support_LED_arriere',carrier,(0,-3,18)),
    ('diffuseur_avant',white,(0,20,12)),('diffuseur_arriere',white,(0,-20,12))],eye=(-100,120,95))
render('supports', [('support_ESP',carrier,(-8,0,-7)),('support_LED_avant',carrier,(18,2,0)),('diffuseur_avant',white,(18,19,0))],eye=(-65,110,100))

font='/System/Library/Fonts/Supplemental/Arial.ttf'
bold='/System/Library/Fonts/Supplemental/Arial Bold.ttf'
def f(size,heavy=False):return ImageFont.truetype(bold if heavy else font,size)
board=Image.new('RGB',(2200,1940),tuple(round(x*255) for x in bg));d=ImageDraw.Draw(board)
ink=(36,44,46);muted=(83,95,96)
d.text((55,35),'TALLY V2  /  PRÊT À PROTOTYPER',font=f(48,True),fill=ink)
d.text((55,103),'Corps 65 × 52 × 32 mm  ·  7 pièces  ·  membrane diffusante 0,4 mm',font=f(29),fill=muted)
panels=[('assemble',0,170,'01  BOÎTIER FERMÉ','Deux diffuseurs opposés ; dessous plat pour le scratch.'),
        ('eclate',1100,170,'02  LES 7 PIÈCES','Socle + couvercle + support ESP + 2 supports LED + 2 diffuseurs.'),
        ('interieur',0,1000,'03  ACCÈS PAR LE DESSUS','Carte violette : enveloppe nominale, composants non représentés.'),
        ('supports',1100,1000,'04  COLLER ET CÂBLER À L’EXTÉRIEUR','Supports amovibles et encoches ouvertes pour les fils.')]
for name,x,y,title,caption in panels:
    d.text((x+40,y),title,font=f(29,True),fill=ink)
    im=Image.open(images/(name+'.png')).convert('RGB');im.thumbnail((1100,690))
    board.paste(im,(x+(1100-im.width)//2,y+50))
    d.text((x+40,y+750),caption,font=f(22),fill=muted)
d.text((55,1830),'Vérifié numériquement : STEP, STL fermés, collisions, insertion et passage libre de 6 × 6,5 mm.',font=f(26),fill=ink)
d.text((55,1878),'À confirmer sur tes pièces : connecteur USB, soudure, collage et jeux des clips. Coupons d’essai fournis.',font=f(25),fill=muted)
board.save(root/'apercu_geometrie_V2.png')
