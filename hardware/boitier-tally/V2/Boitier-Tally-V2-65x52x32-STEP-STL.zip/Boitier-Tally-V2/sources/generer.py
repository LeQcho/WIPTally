"""Tally enclosure V2: top-down assembly, removable glue carriers, open wiring.
Units mm. CadQuery 2.6.1. No firmware files are modified.
"""
from pathlib import Path
import json,itertools
import cadquery as cq
import trimesh

ROOT=Path(__file__).resolve().parent.parent
P=json.loads((ROOT/'sources/parametres.json').read_text())
W,D,H,B=P['width'],P['depth'],P['height'],P['base_height']
T,F=P['wall'],P['floor']; Z=P['led_center_z']
SCREWS=[(-W/2+5,-D/2+5.3),(W/2-5,D/2-5.3)]

def box(x1,x2,y1,y2,z1,z2):
    assert x1<x2 and y1<y2 and z1<z2
    return cq.Workplane('XY').box(x2-x1,y2-y1,z2-z1).translate(((x1+x2)/2,(y1+y2)/2,(z1+z2)/2))

def rr(w,h,r,z):
    return cq.Workplane('XY').rect(w,h).extrude(z).edges('|Z').fillet(r)

def diffuse_place(s,t=.4,back=False):
    s=s.rotate((0,0,0),(1,0,0),90)
    if back:s=s.rotate((0,0,0),(0,0,1),180)
    return s.translate((0,(-1 if back else 1)*(D/2+t+P['diffuser_rim_extra']),Z))

def carrier_place(s,back=False):
    s=s.rotate((0,0,0),(1,0,0),90)
    if not back:s=s.rotate((0,0,0),(0,0,1),180)
    return s.translate((0,(-1 if back else 1)*P['led_plane_y'],Z))

def window():
    return rr(P['window_width'],P['window_height'],2.2,8).rotate((0,0,0),(1,0,0),90).translate((0,D/2+4,Z))

def catches():
    s=None
    for x in [-8,8]:
        b=box(x-2.5,x+2.5,D/2-2.8,D/2-.5,Z+7.2,Z+8.8)
        s=b if s is None else s.union(b)
    return s

def make_diffuser(t):
    seat=t+P['diffuser_rim_extra']
    face=rr(32,18,3,t)
    rim=rr(32,18,3,seat).cut(rr(27.6,13.6,1.8,seat+.2).translate((0,0,-.1)))
    collar=rr(28,14,2,2.6).cut(rr(26,12,1,2.8).translate((0,0,-.1))).translate((0,0,seat-.05))
    for x in [-8,8]:collar=collar.cut(box(x-2.4,x+2.4,5.8,9,seat-.1,seat+2.8))
    s=face.union(rim).union(collar)
    for x in [-8,8]:
        root=box(x-1.8,x+1.8,6.1,7.0,0,seat+.15)
        leaf=box(x-1.75,x+1.75,6.1,6.9,seat-.1,seat+4.4)
        ramp=(cq.Workplane('YZ',origin=(x-1.75,0,0))
              .polyline([(6.9,seat+3.05),(7.35,seat+3.05),(6.9,seat+4.4)])
              .close().extrude(3.5))
        s=s.union(root).union(leaf).union(ramp)
    return s.clean()

def make_led_carrier():
    # Flat back is the print bed. Strip adhesive face is the opposite plane.
    s=rr(40,14,1,2)
    for sign in [-1,1]:
        a,b=sorted([sign*19.9,sign*22])
        s=s.union(box(a,b,-4,4,0,2))
        a,b=sorted([sign*12,sign*18])
        s=s.cut(box(a,b,2,7.2,-.2,2.2))
    return s.clean()

def make_pcb_carrier():
    s=rr(40,31,2,2).translate((-9,0,7))
    s=s.cut(rr(24,13.2,1,3).translate((-11.5,0,6.5)))
    for x in [-24,-2]:
        for sign in [-1,1]:
            a,b=sorted([sign*7.4,sign*9.4])
            s=s.union(box(x-3,x+3,a,b,8.9,11))
    for y in [-11,11]:
        s=s.cut(cq.Workplane('XY').center(8,y).circle(1.2).extrude(4).translate((0,0,6.5)))
    return s.clean()

def guide(sign_x,sign_y):
    def b(x1,x2,y1,y2,z1,z2):
        a,b=sorted([sign_x*x1,sign_x*x2]);c,d=sorted([sign_y*y1,sign_y*y2])
        return box(a,b,c,d,z1,z2)
    s=b(22.3,24.2,17.5,22.5,1.8,27)
    s=s.union(b(19.7,24.2,17.5,18.7,1.8,27))
    s=s.union(b(19.7,24.2,21.3,22.5,1.8,27))
    s=s.union(b(20.2,24.2,18.6,21.4,12.6,13))
    return s

def make_base():
    s=rr(W,D,P['corner'],B).cut(rr(W-2*T,D-2*T,P['corner']-T,B+2).translate((0,0,F)))
    win=window();s=s.cut(win).cut(win.rotate((0,0,0),(0,0,1),180))
    # U-slot remains open to the top: no connector or wire threading needed.
    y=P['usb_aperture_width']/2
    lower=P['usb_center_z']-P['usb_aperture_height']/2
    s=s.cut(box(-W/2-3,-W/2+T+1,-y,y,lower,B+2))
    # Top-open blind rebate accepts the PCB front edge alongside the USB mouth.
    s=s.cut(box(-W/2+1.1,-W/2+T+.2,-13.3,13.3,P['pcb_bottom']-.4,B+1))
    for sy in [-1,1]:
        a,b=sorted([sy*12.5,sy*15.5])
        s=s.union(box(-29,-25,a,b,1.8,7))
        post=cq.Workplane('XY').center(8,sy*11).circle(3).extrude(5.2).translate((0,0,1.8))
        s=s.union(post)
        s=s.cut(cq.Workplane('XY').center(8,sy*11).circle(.85).extrude(5).translate((0,0,2.6)))
        for sx in [-1,1]:s=s.union(guide(sx,sy))
    c=catches();s=s.union(c).union(c.rotate((0,0,0),(0,0,1),180))
    for x,y in SCREWS:
        s=s.union(cq.Workplane('XY').center(x,y).circle(3.5).extrude(B-1.8).translate((0,0,1.8)))
        s=s.cut(cq.Workplane('XY').center(x,y).circle(.85).extrude(10).translate((0,0,B-9)))
    return s.clean()

def make_lid():
    s=rr(W,D,P['corner'],H-B).translate((0,0,B))
    # Integral closing tongue, leaves a 5.8 mm-high USB opening below it.
    z=P['usb_center_z']+P['usb_aperture_height']/2
    s=s.union(box(-W/2,-W/2+T,-5.85,5.85,z,B+.1))
    for y in [-10,10]:s=s.union(box(W/2-3.2,W/2-2.3,y-2,y+2,B-1,B+.1))
    for x,y in SCREWS:
        s=s.cut(cq.Workplane('XY').center(x,y).circle(1.2).extrude(5).translate((0,0,B-.5)))
        s=s.cut(cq.Solid.makeCone(1.2,2.3,1.1,cq.Vector(x,y,H-1.1),cq.Vector(0,0,1)))
    return s.clean()

print('Construction V2...',flush=True)
base=make_base();lid=make_lid();pcb_carrier=make_pcb_carrier();led=make_led_carrier()
d04=make_diffuser(.4);d06=make_diffuser(.6)
front_led=carrier_place(led);rear_led=carrier_place(led,True)
front=diffuse_place(d04);rear=diffuse_place(d04,back=True)
assembled={'socle':base,'couvercle':lid,'support_ESP':pcb_carrier,
           'support_LED_avant':front_led,'support_LED_arriere':rear_led,
           'diffuseur_avant':front,'diffuseur_arriere':rear}
parts={'01_socle_noir':base,
       '02_couvercle_noir':lid.rotate((0,0,0),(1,0,0),180).translate((0,0,H)),
       '03_support_ESP_a_coller':pcb_carrier.translate((0,0,-7)),
       '04_support_LED_a_coller_x2':led,
       '05_diffuseur_blanc_04mm_x2':d04,
       'OPTION_diffuseur_blanc_06mm_x2':d06}

# Small independent fit samples: the actual diffuser seat and one actual LED guide.
sample=box(-19,19,D/2-T,D/2,7,B).cut(window()).union(catches())
parts['TEST_logement_diffuseur']=sample.translate((0,-D/2+4,-7))
sample2=guide(1,1).union(box(18.5,25,16.5,23.5,0,2))
parts['TEST_glissiere_LED']=sample2.translate((-18.5,-16.5,0))
parts['TEST_entree_USB']=base.intersect(box(-W/2,-20,-16,16,0,19))

report={'version':'V2','units':'mm','physical_fit_validated':False,'parts':{},'collisions_mm3':{},'insertion_checks':{}}
for name,s in parts.items():
    print('Export :',name,flush=True)
    assert s.val().isValid() and len(s.solids().vals())==1,name
    cq.exporters.export(s,str(ROOT/'STEP'/f'{name}.step'))
    cq.exporters.export(s,str(ROOT/'STL'/f'{name}.stl'),tolerance=.025,angularTolerance=.08)
    read=cq.importers.importStep(str(ROOT/'STEP'/f'{name}.step'))
    assert read.val().isValid() and len(read.solids().vals())==1,name+' STEP'
    m=trimesh.load_mesh(ROOT/'STL'/f'{name}.stl')
    assert m.is_watertight and m.is_volume,name+' STL'
    assert abs(m.bounds[0,2])<.01,name+' print orientation'
    adj=[[] for _ in range(len(m.faces))]
    for i,j in m.face_adjacency:adj[i].append(j);adj[j].append(i)
    seen={0};todo=[0]
    while todo:
        for j in adj[todo.pop()]:
            if j not in seen:seen.add(j);todo.append(j)
    assert len(seen)==len(m.faces),name+' disconnected mesh'
    bb=s.val().BoundingBox()
    report['parts'][name]={'valid_step':True,'watertight_stl':True,'solids':1,
       'size_mm':[round(bb.xlen,3),round(bb.ylen,3),round(bb.zlen,3)],'volume_mm3':round(s.val().Volume(),2)}

def collision(a,b):return a.intersect(b).val().Volume()
for (n,a),(m,b) in itertools.combinations(assembled.items(),2):
    vol=collision(a,b);report['collisions_mm3'][n+'/'+m]=round(vol,6)
    assert vol<.01,(n,m,vol)

pcb=box(P['pcb_xmin'],P['pcb_xmin']+P['pcb_length'],-P['pcb_width']/2,P['pcb_width']/2,P['pcb_bottom'],P['pcb_bottom']+P['pcb_thickness'])
usb=box(P['pcb_xmin']-P['usb_overhang_assumed'],P['pcb_xmin']+5,-P['usb_width_assumed']/2,P['usb_width_assumed']/2,P['usb_center_z']-P['usb_height_assumed']/2,P['usb_center_z']+P['usb_height_assumed']/2)
for n,a in [('pcb_nominal',pcb),('usb_nominal',usb)]:
    for m,b in assembled.items():
        vol=collision(a,b);assert vol<.01,(n,m,vol)
        report['collisions_mm3'][n+'/'+m]=round(vol,6)

# Verify top-down movement at several heights, including connector clearance.
for n,obj in [('ESP',pcb_carrier.union(pcb).union(usb)),('LED_avant',front_led),('LED_arriere',rear_led)]:
    for dz in [.25,1,3,6,12,20,30]:
        assert collision(base,obj.translate((0,0,dz)))<.01,(n,'insertion blocked',dz)
    report['insertion_checks'][n]='free at +0.25, 1, 3, 6, 12, 20, 30 mm'

channel=box(12,18,-18,18,2.5,9)
for n,s in assembled.items():assert collision(channel,s)<.01,('wire route blocked',n)
report['wire_route_mm']={'width':6,'length':36,'height':6.5,'obstructions':False}
for s,t in [(d04,.4),(d06,.6)]:
    assert s.val().isInside(cq.Vector(0,0,t/2))
    assert not s.val().isInside(cq.Vector(0,0,t+.02))
report['central_membranes_checked_mm']=[.4,.6]
report['usb_protrusion_assumed_mm']=round(-W/2-(P['pcb_xmin']-P['usb_overhang_assumed']),3)

assy=cq.Assembly(name='Tally_V2_65x52x32')
for n,s in assembled.items():assy.add(s,name=n,color=cq.Color(.92,.91,.85) if n.startswith('diffuseur') else cq.Color(.15,.17,.18))
assy.save(str(ROOT/'STEP/00_ASSEMBLAGE_ne_pas_imprimer_en_bloc.step'))
ref=cq.Assembly(name='Enveloppes_nominales_non_imprimables')
for n,s in {'socle':base,'support_ESP':pcb_carrier,'carte_nominale':pcb,'USB_nominal':usb}.items():ref.add(s,name=n)
ref.save(str(ROOT/'STEP/REFERENCE_carte_USB_non_imprimable.step'))

for filename,expected,key in [
    ('00_ASSEMBLAGE_ne_pas_imprimer_en_bloc.step',7,'assembly_step_reimport'),
    ('REFERENCE_carte_USB_non_imprimable.step',4,'reference_step_reimport')]:
    solids=cq.importers.importStep(str(ROOT/'STEP'/filename)).solids().vals()
    assert len(solids)==expected and all(s.isValid() for s in solids),filename
    report[key]={'solids':expected,'all_valid':True}
report['print_stl_min_z_checked']=True

# Positioned STL only for reproducible exact rendering, not for the print folder.
for n,s in assembled.items():cq.exporters.export(s,str(ROOT/'rendus'/f'{n}.stl'),tolerance=.03,angularTolerance=.1)
for n,s in [('carte_nominale',pcb),('USB_nominal',usb)]:cq.exporters.export(s,str(ROOT/'rendus'/f'{n}.stl'))
(ROOT/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
print('V2 vérifiée et exportée.',flush=True)
