# Sources de la V2

Unités : millimètres. Python 3.12, dépendances dans `requirements.txt`.

Depuis le dossier V2 :

```sh
python -m venv .venv
.venv/bin/pip install -r sources/requirements.txt
.venv/bin/python sources/generer.py
.venv/bin/python sources/render_vtk.py
```

Le générateur exporte les STEP et STL, relit les STEP et vérifie les maillages et les collisions. Une assertion échoue si une vérification géométrique ne passe pas. Les paramètres principaux sont dans `parametres.json` ; certains détails de clips et de supports sont définis directement dans le script. Toute modification impose de régénérer et de recontrôler les jeux, y compris sur une impression d’essai.

Le rendu utilise VTK, Pillow et les polices Arial de macOS. Sur une autre plateforme, adapter les chemins de polices dans `render_vtk.py`. Les STL du sous-dossier `rendus` sont positionnés pour ces vues ; utiliser ceux de `STL` pour l’impression.
