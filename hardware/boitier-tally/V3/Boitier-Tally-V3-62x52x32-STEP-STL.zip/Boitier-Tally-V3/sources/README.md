# Sources V3

Python 3.12, unités en millimètres. Depuis le dossier V3 :

```sh
python -m venv .venv
.venv/bin/pip install -r sources/requirements.txt
.venv/bin/python sources/generer.py
.venv/bin/python sources/render_vtk.py
```

Les paramètres principaux sont dans `parametres.json`. Le script définit aussi les détails des supports, de la gorge des diffuseurs et du couvercle. Après modification, régénérer l’ensemble et refaire les essais d’impression : les positions et les jeux dépendent les uns des autres.

Le script exporte les STEP et STL et échoue par assertion si un contrôle géométrique ne passe pas. Il relit aussi les assemblages STEP. `verification.json` décrit les tests et les hypothèses. Le rendu utilise VTK et les polices Arial de macOS ; adapter les chemins de polices sur une autre plateforme. Les STL du sous-dossier `rendus` servent uniquement au rendu ; ceux de `STL` sont orientés pour l’impression.

Fixation ESP : entraxe 20,4 mm et trous de 2 mm d’après le [plan Wemos](https://docs.wemos.cc/en/latest/_static/files/dim_s2_mini_v1.0.0.pdf). La cote longitudinale de 3,3 mm est une estimation graphique, explicitement paramétrée ; la confirmer avec `TEST_fixation_ESP_et_USB` sur la carte réelle. Aucun composant sous la carte n’est détaillé.

L’ESP est vissé directement au socle. Les LED reculent de 2 mm par rapport à V2, sans augmentation de l’encombrement. Les diffuseurs et supports LED sont captifs sous le couvercle. Le ruban LED utilise son adhésif, sans collage structurel des autres pièces.
