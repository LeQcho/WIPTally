"""Actual V3 STL previews. Requires native off-screen VTK graphics."""
from pathlib import Path
import vtk
from PIL import Image,ImageDraw,ImageFont

root=Path(__file__).resolve().parent.parent;images=root/'rendus'
bg=(.965,.957,.931);black=(.25,.28,.30);white=(.94,.93,.87);carrier=(.36,.40,.42)
zero=(0,0,0)

def actor(name,color,offset=zero):
    reader=vtk.vtkSTLReader();reader.SetFileName(str(images/(name+'.stl')));reader.Update()
    normals=vtk.vtkPolyDataNormals();normals.SetInputData(reader.GetOutput());normals.SetFeatureAngle(30);normals.Update()
    mapper=vtk.vtkPolyDataMapper();mapper.SetInputData(normals.GetOutput())
    a=vtk.vtkActor();a.SetMapper(mapper);a.SetPosition(*offset)
    a.GetProperty().SetColor(*color);a.GetProperty().SetAmbient(.35);a.GetProperty().SetDiffuse(.65)
    return a

def render(name,items,eye=(-100,120,110)):
    ren=vtk.vtkRenderer();ren.SetBackground(*bg)
    for n,c,t in items:ren.AddActor(actor(n,c,t))
    cam=ren.GetActiveCamera();cam.ParallelProjectionOn();cam.SetPosition(*eye);cam.SetViewUp(0,0,1)
    win=vtk.vtkRenderWindow();win.SetOffScreenRendering(1);win.SetSize(1100,800);win.AddRenderer(ren)
    ren.ResetCamera();cam.Zoom(1.1);win.Render()
    capture=vtk.vtkWindowToImageFilter();capture.SetInput(win);capture.SetInputBufferTypeToRGB();capture.ReadFrontBufferOff();capture.Update()
    writer=vtk.vtkPNGWriter();writer.SetFileName(str(images/(name+'.png')));writer.SetInputConnection(capture.GetOutputPort());writer.Write();win.Finalize()
    print(name,flush=True)

render('assemble',[(n,white if n.startswith('diffuseur') else black,zero) for n in ['socle','couvercle','diffuseur_avant','diffuseur_arriere']])
render('interieur',[(n,c,zero) for n,c in [('socle',black),('support_LED_avant',carrier),('support_LED_arriere',carrier),('carte_nominale',(.39,.27,.56)),('USB_nominal',(.68,.69,.70)),('ruban_LED_avant_nominal',(.70,.61,.23)),('ruban_LED_arriere_nominal',(.70,.61,.23))]],eye=(-70,75,155))
render('eclate',[
    ('socle',black,zero),('couvercle',black,(0,0,40)),
    ('support_LED_avant',carrier,(0,0,18)),('support_LED_arriere',carrier,(0,0,18)),
    ('diffuseur_avant',white,(0,0,31)),('diffuseur_arriere',white,(0,0,31))],eye=(-100,120,95))
render('retenue', [('diffuseur_avant',white,zero)],eye=(75,-110,90))

font='/System/Library/Fonts/Supplemental/Arial.ttf';bold='/System/Library/Fonts/Supplemental/Arial Bold.ttf'
def f(size,heavy=False):return ImageFont.truetype(bold if heavy else font,size)
board=Image.new('RGB',(2200,1940),tuple(round(x*255) for x in bg));d=ImageDraw.Draw(board)
ink=(36,44,46);muted=(83,95,96)
d.text((55,35),'TALLY V3  /  FIXATIONS MÉCANIQUES',font=f(46,True),fill=ink)
d.text((55,103),'Corps 62 × 52 × 32 mm  ·  LED reculées de 2 mm  ·  diffuseurs de 0,4 mm',font=f(29),fill=muted)
panels=[('assemble',0,170,'01  PLUS COMPACT','Largeur réduite de 3 mm ; hauteur et profondeur conservées.'),
        ('eclate',1100,170,'02  6 PIÈCES IMPRIMÉES','Les diffuseurs et supports LED descendent par le dessus.'),
        ('interieur',0,1000,'03  ESP DIRECTEMENT VISSÉ','Deux plots ; baie libre de 16 × 26 × 22,5 mm pour les fils.'),
        ('retenue',1100,1000,'04  DIFFUSEUR À COLLERETTE RIGIDE','La paroi est prise entre deux bords ; le couvercle bloque la remontée.')]
for name,x,y,title,caption in panels:
    d.text((x+40,y),title,font=f(29,True),fill=ink)
    im=Image.open(images/(name+'.png')).convert('RGB');im.thumbnail((1100,690))
    board.paste(im,(x+(1100-im.width)//2,y+50))
    d.text((x+40,y+750),caption,font=f(22),fill=muted)
d.text((55,1830),'Aucune colle structurelle : 4 vis M2 au total ; adhésif du ruban uniquement sur ses supports.',font=f(26),fill=ink)
d.text((55,1878),'Géométrie vérifiée, impression à tester. Carte et ruban : enveloppes nominales, composants non détaillés.',font=f(25),fill=muted)
board.save(root/'apercu_geometrie_V3.png')
